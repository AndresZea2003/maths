@extends('layouts.app')

@section('main')
    <actividad-8a asset_audio="{{asset('audio')}}" route_back="{{route('normal.level-8.home')}}" route_next="{{route('normal.level-8.b')}}" asset_images="{{asset('images')}}"></actividad-8a>
@endsection
