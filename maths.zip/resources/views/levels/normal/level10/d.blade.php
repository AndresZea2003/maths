@extends('layouts.app')

@section('main')
    <actividad-10d asset_audio="{{asset('audio')}}" route_back="{{route('normal.level-10.home')}}" route_next="{{route('normal.level-10.e')}}" asset_images="{{asset('images')}}"></actividad-10d>
@endsection
