<?php $__env->startSection('main'); ?>
    <div class="min-h-full bg-blue-900">
        <div class="bg-gray-700 container mx-auto px-5 py-5 shadow-2xl rounded-md">
            <div class="font-bold text-xl">Matematicas - Nivel 1</div>
        </div>
        <div class="bg-gray-300 container mx-auto mb-10 mt-10 shadow-2xl rounded-md px-5 py-5">
            <div class="bg-blue-400 flex-col pt-5">
                <div class="flex justify-center">
                    <div class="font-bold text-2xl text-gray-600">Nivel Azul</div>
                </div>
                <div class="mt-5 gap-5 grid md:grid-cols-4 sm:grid-cols-1 mx-5">
                    <a href="<?php echo e(route('normal.level-1')); ?>">
                        <div
                            class="bg-blue-300 p-5 rounded-md shadow-2xl border-blue-400 border-4 flex justify-center hover:scale-90 duration-300 cursor-pointer">
                            <div>
                                <div class="flex justify-center">
                                    <div class="font-bold text-2xl">
                                        Nivel 1
                                    </div>
                                </div>
                                <div class="w-20">
                                    <mati-1 asset="<?php echo e(asset('images')); ?>"></mati-1>
                                </div>
                            </div>
                        </div>
                    </a>
                    <div
                        class="bg-orange-300 p-5 rounded-md shadow-2xl border-orange-400 border-4 flex justify-center hover:scale-90 duration-300 cursor-pointer">
                        <div>
                            <div class="flex justify-center">
                                <div class="font-bold text-2xl">
                                    Nivel 2
                                </div>
                            </div>
                            <div class="w-20">
                                <mati-1 asset="<?php echo e(asset('images')); ?>"></mati-1>
                            </div>
                        </div>
                    </div>
                    <div
                        class="bg-green-300 p-5 rounded-md shadow-2xl border-green-400 border-4 flex justify-center hover:scale-90 duration-300 cursor-pointer">
                        <div>
                            <div class="flex justify-center">
                                <div class="font-bold text-2xl">
                                    Nivel 3
                                </div>
                            </div>
                            <div class="w-20">
                                <mati-1 asset="<?php echo e(asset('images')); ?>"></mati-1>
                            </div>
                        </div>
                    </div>
                    <div
                        class="bg-violet-300 p-5 rounded-md shadow-2xl border-violet-400 border-4 flex justify-center hover:scale-90 duration-300 cursor-pointer">
                        <div>
                            <div class="flex justify-center">
                                <div class="font-bold text-2xl">
                                    Nivel 4
                                </div>
                            </div>
                            <div class="w-20">
                                <mati-1 asset="<?php echo e(asset('images')); ?>"></mati-1>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="p-5">
                    <a href="<?php echo e(route('home')); ?>">
                        <button
                            class="bg-red-300 px-2 py-1 rounded-md border-red-800 border-2 flex items-center hover:text-white hover:bg-gray-700 hover:scale-90 duration-300">
                            <home-icon class="h-7 w-7"></home-icon>
                            <span class="font-bold">&nbspVolver</span>
                        </button>
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\maths\resources\views/levels/normal/level-1.blade.php ENDPATH**/ ?>