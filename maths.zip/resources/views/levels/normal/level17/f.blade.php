@extends('layouts.app')

@section('main')
    <actividad-17f asset_audio="{{asset('audio')}}" route_back="{{route('normal.level-17.home')}}" route_next="{{route('normal.level-17.home')}}" asset_images="{{asset('images')}}"></actividad-17f>
@endsection
