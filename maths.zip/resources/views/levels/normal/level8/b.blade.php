@extends('layouts.app')

@section('main')
    <actividad-8b asset_audio="{{asset('audio')}}" route_back="{{route('normal.level-8.home')}}" route_next="{{route('normal.level-8.c')}}" asset_images="{{asset('images')}}"></actividad-8b>
@endsection
