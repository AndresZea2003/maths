<script setup>
import {HomeIcon} from "@heroicons/vue/20/solid";
import {ArrowDownIcon, CheckBadgeIcon, ChevronRightIcon} from "@heroicons/vue/24/solid"
import Swal from 'sweetalert2'
import {ref} from "vue";

let color = 'white';
let content = null;
let num1 = ref(null)
let num2 = ref(null)
let num3 = ref(null)
let num4 = ref(null)
let num5 = ref(null)
let num6 = ref(null)
let num7 = ref(null)
let num8 = ref(null)
let num9 = ref(null)
let num10 = ref(null)
let num11 = ref(null)
let num12 = ref(null)
let num13 = ref(null)
let num14 = ref(null)
let num15 = ref(null)
let num16 = ref(null)
let num17 = ref(null)
let num18 = ref(null)

const props = defineProps({
    route_back: {type: String, required: true},
    route_next: {type: String, required: true},
    asset_images: {type: String, required: true},
    asset_audio: {type: String, required: true}
})

let mati = ref(`${props.asset_images}/robot/mati_act1.gif`)

const sol = ref(`${props.asset_images}/cosas/sol.svg`)
const corazon = ref(`${props.asset_images}/cosas/corazon.svg`)
const hoja = ref(`${props.asset_images}/cosas/hoja.svg`)

const add = (num) => {

    if (num === 'num1') {
        if (content != null) {
            document.getElementById('num1').classList.remove('p-7')
            document.getElementById('num1').classList.add('p-4')
            num1.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num1.value = null
            document.getElementById('num1').classList.remove('py-3')
            document.getElementById('num1').classList.remove('px-5')
            document.getElementById('num1').classList.add('p-7')
        }
    } else if (num === 'num2') {
        if (content != null) {
            document.getElementById('num2').classList.remove('p-7')
            document.getElementById('num2').classList.add('p-4')
            num2.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num2.value = null
            document.getElementById('num2').classList.remove('py-3')
            document.getElementById('num2').classList.remove('px-5')
            document.getElementById('num2').classList.add('p-7')
        }
    } else if (num === 'num3') {
        if (content != null) {
            document.getElementById('num3').classList.remove('p-7')
            document.getElementById('num3').classList.add('p-4')
            num3.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num3.value = null
            document.getElementById('num3').classList.remove('py-3')
            document.getElementById('num3').classList.remove('px-5')
            document.getElementById('num3').classList.add('p-7')
        }
    } else if (num === 'num4') {
        if (content != null) {
            document.getElementById('num4').classList.remove('p-7')
            document.getElementById('num4').classList.add('p-4')
            num4.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num4.value = null
            document.getElementById('num4').classList.remove('py-3')
            document.getElementById('num4').classList.remove('px-5')
            document.getElementById('num4').classList.add('p-7')
        }
    } else if (num === 'num5') {
        if (content != null) {
            document.getElementById('num5').classList.remove('p-7')
            document.getElementById('num5').classList.add('p-4')
            num5.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num5.value = null
            document.getElementById('num5').classList.remove('py-3')
            document.getElementById('num5').classList.remove('px-5')
            document.getElementById('num5').classList.add('p-7')
        }
    } else if (num === 'num6') {
        if (content != null) {
            document.getElementById('num6').classList.remove('p-7')
            document.getElementById('num6').classList.add('p-4')
            num6.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num6.value = null
            document.getElementById('num6').classList.remove('py-3')
            document.getElementById('num6').classList.remove('px-5')
            document.getElementById('num6').classList.add('p-7')
        }
    } else if (num === 'num7') {
        if (content != null) {
            document.getElementById('num7').classList.remove('p-7')
            document.getElementById('num7').classList.add('p-4')
            num7.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num7.value = null
            document.getElementById('num7').classList.remove('py-3')
            document.getElementById('num7').classList.remove('px-5')
            document.getElementById('num7').classList.add('p-7')
        }
    } else if (num === 'num8') {
        if (content != null) {
            document.getElementById('num8').classList.remove('p-7')
            document.getElementById('num8').classList.add('p-4')
            num8.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num8.value = null
            document.getElementById('num8').classList.remove('py-3')
            document.getElementById('num8').classList.remove('px-5')
            document.getElementById('num8').classList.add('p-7')
        }
    } else if (num === 'num9') {
        if (content != null) {
            document.getElementById('num9').classList.remove('p-7')
            document.getElementById('num9').classList.add('p-4')
            num9.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num9.value = null
            document.getElementById('num9').classList.remove('py-3')
            document.getElementById('num9').classList.remove('px-5')
            document.getElementById('num9').classList.add('p-7')
        }
    } else if (num === 'num10') {
        if (content != null) {
            document.getElementById('num10').classList.remove('p-7')
            document.getElementById('num10').classList.add('p-4')
            num10.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num10.value = null
            document.getElementById('num10').classList.remove('py-3')
            document.getElementById('num10').classList.remove('px-5')
            document.getElementById('num10').classList.add('p-7')
        }
    } else if (num === 'num11') {
        if (content != null) {
            document.getElementById('num11').classList.remove('p-7')
            document.getElementById('num11').classList.add('p-4')
            num11.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num11.value = null
            document.getElementById('num11').classList.remove('py-3')
            document.getElementById('num11').classList.remove('px-5')
            document.getElementById('num11').classList.add('p-7')
        }
    } else if (num === 'num12') {
        if (content != null) {
            document.getElementById('num12').classList.remove('p-7')
            document.getElementById('num12').classList.add('p-4')
            num12.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num12.value = null
            document.getElementById('num12').classList.remove('py-3')
            document.getElementById('num12').classList.remove('px-5')
            document.getElementById('num12').classList.add('p-7')
        }
    } else if (num === 'num13') {
        if (content != null) {
            document.getElementById('num13').classList.remove('p-7')
            document.getElementById('num13').classList.add('p-4')
            num13.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num13.value = null
            document.getElementById('num13').classList.remove('py-3')
            document.getElementById('num13').classList.remove('px-5')
            document.getElementById('num13').classList.add('p-7')
        }
    } else if (num === 'num14') {
        if (content != null) {
            document.getElementById('num14').classList.remove('p-7')
            document.getElementById('num14').classList.add('p-4')
            num14.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num14.value = null
            document.getElementById('num14').classList.remove('py-3')
            document.getElementById('num14').classList.remove('px-5')
            document.getElementById('num14').classList.add('p-7')
        }
    } else if (num === 'num15') {
        if (content != null) {
            document.getElementById('num15').classList.remove('p-7')
            document.getElementById('num15').classList.add('p-4')
            num15.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num15.value = null
            document.getElementById('num15').classList.remove('py-3')
            document.getElementById('num15').classList.remove('px-5')
            document.getElementById('num15').classList.add('p-7')
        }
    } else if (num === 'num16') {
        if (content != null) {
            document.getElementById('num16').classList.remove('p-7')
            document.getElementById('num16').classList.add('p-4')
            num16.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num16.value = null
            document.getElementById('num16').classList.remove('py-3')
            document.getElementById('num16').classList.remove('px-5')
            document.getElementById('num16').classList.add('p-7')
        }
    } else if (num === 'num17') {
        if (content != null) {
            document.getElementById('num17').classList.remove('p-7')
            document.getElementById('num17').classList.add('p-4')
            num17.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num17.value = null
            document.getElementById('num17').classList.remove('py-3')
            document.getElementById('num17').classList.remove('px-5')
            document.getElementById('num17').classList.add('p-7')
        }
    } else if (num === 'num18') {
        if (content != null) {
            document.getElementById('num18').classList.remove('p-7')
            document.getElementById('num18').classList.add('p-4')
            num18.value = `${props.asset_images}/cosas/${content}.svg`
        } else {
            num18.value = null
            document.getElementById('num18').classList.remove('py-3')
            document.getElementById('num18').classList.remove('px-5')
            document.getElementById('num18').classList.add('p-7')
        }
    }
}


const paint = (id) => {

    if (color === 'white1') {
        Swal.fire({
            icon: 'warning',
            title: 'Falta color!',
            text: 'Selecciona un color primero',
            showConfirmButton: true,
        })
    }

    let sound = new Audio();
    sound.src = `${props.asset_audio}/paint.wav`;
    sound.play()

    document.getElementById(id).classList.remove('hover:bg-gray-400')
    document.getElementById(id).classList.remove('bg-white')
    document.getElementById(id).classList.remove('bg-red-600')
    document.getElementById(id).classList.remove('bg-yellow-400')
    document.getElementById(id).classList.remove('bg-yellow-400')
    document.getElementById(id).classList.remove('bg-white')
    document.getElementById(id).classList.add(`bg-${color}`);

    // Figura 1
    if (document.getElementById('caja1').classList.contains('bg-white') &&
        document.getElementById('caja2').classList.contains('bg-white') &&
        document.getElementById('caja3').classList.contains('bg-white') &&
        document.getElementById('caja4').classList.contains('bg-white') &&
        document.getElementById('caja5').classList.contains('bg-white') &&
        document.getElementById('caja6').classList.contains('bg-white') &&
        document.getElementById('caja7').classList.contains('bg-white') &&
        document.getElementById('caja8').classList.contains('bg-white') &&
        document.getElementById('caja9').classList.contains('bg-white') &&
        document.getElementById('caja10').classList.contains('bg-white') &&
        document.getElementById('caja11').classList.contains('bg-white') &&
        document.getElementById('caja12').classList.contains('bg-white') &&
        document.getElementById('caja13').classList.contains('bg-white') &&
        document.getElementById('caja14').classList.contains('bg-white') &&
        document.getElementById('caja15').classList.contains('bg-white') &&
        document.getElementById('caja16').classList.contains('bg-white') &&
        document.getElementById('caja17').classList.contains('bg-white') &&
        document.getElementById('caja18').classList.contains('bg-white') &&
        document.getElementById('caja19').classList.contains('bg-white') &&
        document.getElementById('caja20').classList.contains('bg-yellow-400') &&
        document.getElementById('caja21').classList.contains('bg-white') &&
        document.getElementById('caja22').classList.contains('bg-white') &&
        document.getElementById('caja23').classList.contains('bg-white') &&
        document.getElementById('caja24').classList.contains('bg-yellow-400') &&
        document.getElementById('caja25').classList.contains('bg-yellow-400') &&
        document.getElementById('caja26').classList.contains('bg-white') &&
        document.getElementById('caja27').classList.contains('bg-white') &&
        document.getElementById('caja28').classList.contains('bg-yellow-400') &&
        document.getElementById('caja29').classList.contains('bg-yellow-400') &&
        document.getElementById('caja30').classList.contains('bg-yellow-400') &&
        document.getElementById('caja31').classList.contains('bg-white') &&
        document.getElementById('caja32').classList.contains('bg-yellow-400') &&
        document.getElementById('caja33').classList.contains('bg-yellow-400') &&
        document.getElementById('caja34').classList.contains('bg-yellow-400') &&
        document.getElementById('caja35').classList.contains('bg-yellow-400') &&
        document.getElementById('caja36').classList.contains('bg-yellow-400') &&
        document.getElementById('caja37').classList.contains('bg-yellow-400') &&
        document.getElementById('caja38').classList.contains('bg-yellow-400') &&
        document.getElementById('caja39').classList.contains('bg-yellow-400') &&
        document.getElementById('caja40').classList.contains('bg-yellow-400')
    ) {

        if (figura1 === 0) {
            let sound = new Audio();
            sound.src = `${props.asset_audio}/coin.wav`;
            sound.play()
            figura1++

            Swal.fire({
                icon: 'success',
                title: 'Completado!',
                text: 'Felicidades! Has completado la actividad',
                showConfirmButton: true,
            })

            mati.value = `${props.asset_images}/robot/mati.gif`
            document.getElementById('fondoMati').classList.remove('bg-red-300')
            document.getElementById('fondoMati').classList.add('bg-green-300')
        }
    } else {
        document.getElementById('fig1').classList.remove('text-red-500')
        document.getElementById('fig1').classList.add('text-gray-300')
    }
}

const selectItem = (item) => {


    content = item

    // document.getElementById('muestra').classList.remove('bg-red-600')
    // document.getElementById('muestra').classList.remove('bg-white')
    // document.getElementById('muestra').classList.remove('bg-yellow-400')
    // document.getElementById('muestra').classList.remove('bg-yellow-400')
    // document.getElementById('muestra').classList.remove('bg-white')
    //
    // document.getElementById('muestra').classList.add(`bg-${color}`)

    let sound = new Audio();
    sound.src = `${props.asset_audio}/bubble.wav`;
    sound.play()
}

const selectColor = (bg) => {
    color = bg

    document.getElementById('muestra').classList.remove('bg-blue-600')
    document.getElementById('muestra').classList.remove('bg-red-600')
    document.getElementById('muestra').classList.remove('bg-green-600')
    document.getElementById('muestra').classList.remove('bg-yellow-400')
    document.getElementById('muestra').classList.remove('bg-white')

    document.getElementById('muestra').classList.add(`bg-${color}`)

    let sound = new Audio();
    sound.src = `${props.asset_audio}/bubble.wav`;
    sound.play()
}

</script>

<template>
    <div class="min-h-full bg-space">
        <div class="md:container mx-auto">
            <div class="font-bold text-xl bg-gray-900 mx-5 px-5 py-3 rounded-b-lg shadow-2xl text-white">Matematicas -
                Nivel 17
            </div>
        </div>
        <div class="container mx-auto mb-10 rounded-md px-5">
            <div class="bg-orange-300 border-4 border-stone-600 flex-col pb-2 rounded-md shadow-2xl">
                <div class="mx-5 py-2">
                    <div>
                        <span class="font-bold">Actividad 7 -</span>
                        <span> Completa los sudokus presentados a continuacion</span>
                    </div>
                </div>
                <div class="mx-5 grid md:grid-cols-4 gap-5">
                    <div id="fondoMati"
                         class="bg-red-300 border-4 border-red-600 rounded-md flex items-end justify-center">
                        <div class="">
                            <img :src="mati" width="250"
                                 alt="">
                        </div>
                    </div>
                    <div
                        class="bg-white border-4 border-stone-600 rounded-md p-5 md:col-span-3 grid md:grid-cols-4 gap-5">
                        <div class="col-span-4 gap-x-10">
                            <div class="flex justify-center">
                                <div class="font-bold text-2xl">COMPLETAR</div>
                            </div>
                            <div
                                class="border-black border-4 flex items-center justify-center p-5 grid grid-cols-3 bg-yellow-200">
                                <div>
                                    <div class="flex justify-center">
                                        <div class="font-bold text-2xl">Figura 1</div>
                                    </div>
                                    <div id="fig1" class="flex justify-center text-gray-300">
                                        <CheckBadgeIcon class="w-20"/>
                                    </div>
                                </div>

                                <div>
                                    <div class="flex justify-center">
                                        <div class="font-bold text-2xl">Figura 2</div>
                                    </div>
                                    <div id="fig1" class="flex justify-center text-gray-300">
                                        <CheckBadgeIcon class="w-20"/>
                                    </div>
                                </div>

                                <div>
                                    <div class="flex justify-center">
                                        <div class="font-bold text-2xl">Figura 3</div>
                                    </div>
                                    <div id="fig1" class="flex justify-center text-gray-300">
                                        <CheckBadgeIcon class="w-20"/>
                                    </div>
                                </div>

                                <div class="flex justify-center">
                                    <div>
                                        <div class="grid grid-cols-3">
                                            <button
                                                class="bg-white border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-red-600 border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-blue-600 border-black border flex justify-center items-center p-7">
                                            </button>
                                        </div>

                                        <div class="grid grid-cols-3">
                                            <button
                                                class="bg-red-600 border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-blue-600 border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-white border-black border flex justify-center items-center p-7">
                                            </button>
                                        </div>

                                        <div class="grid grid-cols-3">
                                            <button
                                                class="bg-white border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-yellow-400 border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-red-600 border-black border flex justify-center items-center p-7">
                                            </button>
                                        </div>

                                    </div>
                                </div>
                                <div class=" flex justify-center">
                                    <div>
                                        <div class="grid grid-cols-3">
                                            <button @click="add('num1')"
                                                    class="bg-white border-black border flex justify-center items-center p-7"
                                                    id="num1">
                                                <img :src="num1">
                                            </button>
                                            <button @click="add('num2')"
                                                    class="bg-red-600 border-black border flex justify-center items-center p-7"
                                                    id="num2">
                                                <img :src="num2">
                                            </button>
                                            <button @click="add('num3')"
                                                    class="bg-blue-600 border-black border flex justify-center items-center p-7"
                                                    id="num3">
                                                <img :src="num3">
                                            </button>
                                        </div>

                                        <div class="grid grid-cols-3">
                                            <button @click="add('num4')"
                                                    class="bg-red-600 border-black border flex justify-center items-center p-7"
                                                    id="num4">
                                                <img :src="num4">
                                            </button>
                                            <button @click="add('num5')"
                                                    class="bg-blue-600 border-black border flex justify-center items-center p-7"
                                                    id="num5">
                                                <img :src="num5">
                                            </button>
                                            <button @click="add('num6')"
                                                    class="bg-white border-black border flex justify-center items-center p-7"
                                                    id="num6">
                                                <img :src="num6">
                                            </button>
                                        </div>

                                        <div class="grid grid-cols-3">
                                            <button @click="add('num7')"
                                                    class="bg-white border-black border flex justify-center items-center p-7"
                                                    id="num7">
                                                <img :src="num7">
                                            </button>
                                            <button @click="add('num8')"
                                                    class="bg-yellow-400 border-black border flex justify-center items-center p-7"
                                                    id="num8">
                                                <img :src="num8">
                                            </button>
                                            <button @click="add('num9')"
                                                    class="bg-red-600 border-black border flex justify-center items-center p-7"
                                                    id="num9">
                                                <img :src="num9">
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="flex justify-center">
                                    <div>
                                        <div class="grid grid-cols-3">
                                            <button
                                                class="bg-white border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-red-600 border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-blue-600 border-black border flex justify-center items-center p-7">
                                            </button>
                                        </div>

                                        <div class="grid grid-cols-3">
                                            <button
                                                class="bg-red-600 border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-blue-600 border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-white border-black border flex justify-center items-center p-7">
                                            </button>
                                        </div>

                                        <div class="grid grid-cols-3">
                                            <button
                                                class="bg-white border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-yellow-400 border-black border flex justify-center items-center p-7">
                                            </button>
                                            <button
                                                class="bg-red-600 border-black border flex justify-center items-center p-7">
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-span-3 grid grid-cols-3 mt-2">
                                    <div class="flex justify-center gap-5">
                                        <div id="fig1" class="text-gray-300">
                                            <CheckBadgeIcon class="w-10"/>
                                        </div>
                                        <div id="fig1" class="text-gray-300">
                                            <CheckBadgeIcon class="w-10"/>
                                        </div>
                                        <div id="fig1" class="text-gray-300">
                                            <CheckBadgeIcon class="w-10"/>
                                        </div>
                                    </div>

                                    <div class="flex justify-center gap-5">
                                        <div id="fig1" class="text-gray-300">
                                            <CheckBadgeIcon class="w-10"/>
                                        </div>
                                        <div id="fig1" class="text-gray-300">
                                            <CheckBadgeIcon class="w-10"/>
                                        </div>
                                        <div id="fig1" class="text-gray-300">
                                            <CheckBadgeIcon class="w-10"/>
                                        </div>
                                    </div>

                                    <div class="flex justify-center gap-5">
                                        <div id="fig1" class="text-gray-300">
                                            <CheckBadgeIcon class="w-10"/>
                                        </div>
                                        <div id="fig1" class="text-gray-300">
                                            <CheckBadgeIcon class="w-10"/>
                                        </div>
                                        <div id="fig1" class="text-gray-300">
                                            <CheckBadgeIcon class="w-10"/>
                                        </div>
                                    </div>
                                </div>

                                <div class=" col-span-3 mt-5 grid grid-cols-3">
                                    <div class="flex justify-center">
                                        <button @click="selectColor('blue-600')"
                                                class="border-2 border-black bg-blue-600 hover:bg-blue-700 rounded-full p-5">
                                            {{ null }}
                                        </button>
                                    </div>
                                    <div class="flex justify-center">
                                        <button @click="selectColor('red-600')"
                                                class="border-2 border-black bg-red-600 hover:bg-red-700 rounded-full p-5">
                                            {{ null }}
                                        </button>
                                    </div>
                                    <div class="flex justify-center">
                                        <button @click="selectColor('yellow-400')"
                                                class="border-2 border-black bg-yellow-400 hover:bg-yellow-500 rounded-full p-5">
                                            {{ null }}
                                        </button>
                                    </div>
                                    <div id="muestra" class="border-2 border-black p-10 m-2 bg-white col-span-3"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="grid grid-cols-2">
                    <div class="px-5 pt-2 flex">
                        <div>
                            <a :href="props.route_back">
                                <button
                                    class="bg-red-300 px-2 py-1 rounded-md border-red-800 border-2 flex items-center hover:text-white hover:bg-gray-700 hover:scale-90 duration-300">
                                    <HomeIcon class="h-7 w-7"></HomeIcon>
                                    <span class="font-bold">&nbspVolver</span>
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="px-5 pt-2 flex justify-end">
                        <div>
                            <a :href="props.route_next">
                                <button
                                    class="bg-red-300 px-2 py-1 rounded-md border-red-800 border-2 flex items-center hover:text-white hover:bg-gray-700 hover:scale-90 duration-300">
                                    <span class="font-bold">&nbspSiguiente</span>
                                    <ChevronRightIcon class="h-7 w-7"></ChevronRightIcon>
                                </button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
