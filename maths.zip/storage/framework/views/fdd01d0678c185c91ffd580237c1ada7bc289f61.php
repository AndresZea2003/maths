<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <main class="h-screen w-screen" id="app">
        <?php echo $__env->yieldContent('main'); ?>
    </main>
</body>
</html>
<?php /**PATH C:\laragon\www\maths\resources\views/Layouts/app.blade.php ENDPATH**/ ?>