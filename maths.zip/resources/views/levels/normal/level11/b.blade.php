@extends('layouts.app')

@section('main')
    <actividad-11b asset_audio="{{asset('audio')}}" route_back="{{route('normal.level-11.home')}}" route_next="{{route('normal.level-11.c')}}" asset_images="{{asset('images')}}"></actividad-11b>
@endsection
