<?php $__env->startSection('main'); ?>
    <actividad-11b asset_audio="<?php echo e(asset('audio')); ?>" route_back="<?php echo e(route('normal.level-11.home')); ?>" route_next="<?php echo e(route('normal.level-11.c')); ?>" asset_images="<?php echo e(asset('images')); ?>"></actividad-11b>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\maths\resources\views/levels/normal/level11/b.blade.php ENDPATH**/ ?>