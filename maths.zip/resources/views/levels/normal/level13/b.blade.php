@extends('layouts.app')

@section('main')
    <actividad-13b asset_audio="{{asset('audio')}}" route_back="{{route('normal.level-13.home')}}" route_next="{{route('normal.level-13.c')}}" asset_images="{{asset('images')}}"></actividad-13b>
@endsection
