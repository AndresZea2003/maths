<script setup>

import { Cog8ToothIcon } from '@heroicons/vue/24/solid'

</script>

<template>
    <div class="bg-violet-900 p-5 rounded-md shadow-md">
        <div class="flex items-center">
            <Cog8ToothIcon class="h-5 w-5" aria-hidden="true"/>
            <div>&nbspConfiguracion</div>
        </div>
    </div>

</template>
