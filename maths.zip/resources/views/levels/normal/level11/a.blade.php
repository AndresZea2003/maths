@extends('layouts.app')

@section('main')
    <actividad-11a asset_audio="{{asset('audio')}}" route_back="{{route('normal.level-11.home')}}" route_next="{{route('normal.level-11.b')}}" asset_images="{{asset('images')}}"></actividad-11a>
@endsection
