@extends('layouts.app')

@section('main')
    <actividad-11f asset_audio="{{asset('audio')}}" route_back="{{route('normal.level-11.home')}}" route_next="{{route('normal.level-11.g')}}" asset_images="{{asset('images')}}"></actividad-11f>
@endsection
