@extends('layouts.app')

@section('main')
    <actividad-9d asset_audio="{{asset('audio')}}" route_back="{{route('normal.level-9.home')}}" route_next="{{route('normal.level-9.e')}}" asset_images="{{asset('images')}}"></actividad-9d>
@endsection
