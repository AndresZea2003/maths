@extends('layouts.app')

@section('main')
    <actividad-8c asset_audio="{{asset('audio')}}" route_back="{{route('normal.level-8.home')}}" route_next="{{route('normal.level-8.home')}}" asset_images="{{asset('images')}}"></actividad-8c>
@endsection
