<?php $__env->startSection('main'); ?>
    <actividad-4f asset_audio="<?php echo e(asset('audio')); ?>" route_back="<?php echo e(route('normal.level-4.home')); ?>" route_next="<?php echo e(route('normal.level-4.g')); ?>" route_refresh="<?php echo e(route('normal.level-4.f')); ?>" asset_images="<?php echo e(asset('images')); ?>"></actividad-4a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\maths\resources\views/levels/normal/level4/f.blade.php ENDPATH**/ ?>