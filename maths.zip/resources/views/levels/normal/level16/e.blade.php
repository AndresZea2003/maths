@extends('layouts.app')

@section('main')
    <actividad-16e asset_audio="{{asset('audio')}}" route_back="{{route('normal.level-16.home')}}" route_next="{{route('normal.level-16.f')}}" asset_images="{{asset('images')}}"></actividad-16e>
@endsection
